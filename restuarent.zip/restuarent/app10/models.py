from django.db import models

class Menu(models.Model):
    name=models.CharField(max_length=20)
    desc=models.TextField()

    def __str__(self):
        return self.name

class MenuItem(models.Model):
    name = models.CharField(max_length=40)
    price=models.DecimalField(max_digits=10,decimal_places=2)
    menu=models.ForeignKey(Menu,on_delete=models.CASCADE,related_name="menu_item")
    is_vegetarian = models.BooleanField(default=True)

    def __str__(self):
        return self.name

