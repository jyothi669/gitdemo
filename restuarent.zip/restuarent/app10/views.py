from django.shortcuts import render
from django.urls import reverse_lazy
from app10.models import Menu,MenuItem
from django.views.generic import DetailView, CreateView,UpdateView,ListView





class Category(CreateView):
    model=Menu
    fields = '__all__'
    template_name = 'category.html'



class Details(DetailView):
    model=MenuItem
    template_name = 'item_details.html'
    context_object_name = 'item_details'

class Update(UpdateView):
    template_name='update.html'
    fields=['name','price','menu','is_vegetarian']
    model=MenuItem
    success_url=reverse_lazy('home')