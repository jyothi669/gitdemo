from django.contrib import admin
from app10.models import Menu,MenuItem
# Register your models here.
admin.site.register(Menu)
admin.site.register(MenuItem)

